package com.SupportUi.forms;

import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.Retailsols.com.MyLogger;
import com.Retailsols.com.SupportUI;
import com.Retailsols.com.VerifyStoreNumber;
import com.retail.service.DelAsnMnt;
import com.retail.service.StrBankMnt;
import javax.swing.JComboBox;

public class DelAsnPannel {
	
	private static String strnbr;
	private static String asnid;

	/**
	 * @wbp.parser.entryPoint
	 */
	public static Panel getDelAsnPanel()
	{
		Panel delasn = new Panel();
		delasn.setBackground(new Color(30, 144, 255));
		delasn.setLayout(null);
	
		
		Label label_12 = new Label("Store Number");
		label_12.setBounds(205, 141, 82, 14);
		delasn.add(label_12);
		
		JTextField textField_8 = new JTextField();
		textField_8.setBounds(320, 138, 86, 20);
		delasn.add(textField_8);
		
		Label label_13 = new Label("ASN Document Number");
		label_13.setBounds(205, 172, 100, 14);
		delasn.add(label_13);
		
		JTextField textField_9 = new JTextField();
		textField_9.setBounds(320, 172, 86, 20);
		delasn.add(textField_9);
		
		//instrution1
		JLabel instruction_1 = new JLabel("1.For Deleting the ASN's,the Length of the ASN number should be 15 digits ");
		instruction_1.setFont(new Font("Serif",Font.PLAIN,16));
		instruction_1.setForeground(Color.BLACK);

		instruction_1.setBounds(459, 130, 750, 43);
		delasn.add(instruction_1);
		//instruction2
		JLabel instruction_2 = new JLabel("2.ASN number should start with Store number");
		instruction_2.setFont(new Font("Serif",Font.PLAIN,16));
		instruction_2.setForeground(Color.BLACK);

		instruction_2.setBounds(459, 172, 606, 43);
		delasn.add(instruction_2);
		
		JButton btnNewButton_1 = new JButton("Process");
		btnNewButton_1.setBackground(new Color(255, 51, 0));
		btnNewButton_1.setBounds(244, 252, 162, 37);
		delasn.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("Approved By");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(210, 202, 100, 20);
		delasn.add(lblNewLabel);
		
		String[] str = { "", "Andre F","Rodriguez" };
		JComboBox comboBox = new JComboBox<Object>(str);
		comboBox.setBounds(320, 202, 86, 20);
		delasn.add(comboBox);
		
		
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				strnbr=textField_8.getText();
				asnid=textField_9.getText();
				if(!VerifyStoreNumber.validteStore(strnbr))
				{
					SupportUI.statuslabel.setText("Invalid store number");
					MyLogger.log(Level.INFO, "enterd invalid store number: "+strnbr+"");
				}
				else
				{
					DelAsnMnt.genDelAsnMnt(strnbr, asnid);
					SupportUI.statuslabel.setText("Mnt has been generated sucessfully");
					MyLogger.log(Level.INFO, "delete asn mnt has genereted for the store: "+strnbr+"");
					MyLogger.log(Level.INFO, "delete asn mnt has genereted and Approved by: "+comboBox+"");
					
					textField_8.setText("");
					textField_9.setText("");
					comboBox.setSelectedIndex(0);
				}
				
			}
		});
		return delasn;
	}
}
