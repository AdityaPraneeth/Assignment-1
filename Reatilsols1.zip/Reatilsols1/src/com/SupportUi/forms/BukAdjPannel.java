package com.SupportUi.forms;

import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;

import com.Retailsols.com.MyLogger;
import com.Retailsols.com.SupportLogin;
import com.Retailsols.com.SupportUI;
import com.Retailsols.com.VerifyBucketId;
import com.Retailsols.com.VerifyReasonCode;
import com.Retailsols.com.VerifyStoreNumber;
import com.retail.bo.InvBucketAdjustBo;
import com.retail.dao.InvBucketAdjustmentDao;
import com.retail.service.InvBucketAdjustServices;
import com.retail.service.CountMnt;

public class BukAdjPannel {

	/**
	 * @wbp.parser.entryPoint
	 */
	public static Panel getBukAdjPanel() {
		String[] str = { "select", "ON_HAND", "DAMAGED", "DEMO", "EARLY_UPGRADE", "TRADE_IN" };
		String[] str1= { "select", "Damage", "Return To Stock", "Theft","Demo" };
		Panel bucketadjpannel = new Panel();
		bucketadjpannel.setBackground(new Color(30, 144, 255));
		bucketadjpannel.setLayout(null);

		Label label_7 = new Label("Bucket Adjustment Issue");
		bucketadjpannel.add(label_7);

		Label label_14 = new Label("Store Number");
		label_14.setBounds(190, 66, 80, 22);
		bucketadjpannel.add(label_14);

		JTextField textField_11 = new JTextField();
		textField_11.setBounds(333, 66, 119, 22);
		bucketadjpannel.add(textField_11);

		Label label_15 = new Label("SKU");
		label_15.setBounds(190, 112, 35, 22);
		bucketadjpannel.add(label_15);

		JTextField textField_12 = new JTextField();
		textField_12.setBounds(333, 112, 119, 22);
		bucketadjpannel.add(textField_12);

		Label label_16 = new Label("IMEI");
		label_16.setBounds(190, 146, 35, 22);
		bucketadjpannel.add(label_16);

		JTextField textField_13 = new JTextField();
		textField_13.setBounds(333, 146, 119, 22);
		bucketadjpannel.add(textField_13);

		Label label_17 = new Label("Bucket");
		label_17.setBounds(190, 176, 41, 22);
		bucketadjpannel.add(label_17);

		JComboBox bct = new JComboBox(str);
		bct.setBounds(333, 178, 119, 20);
		bucketadjpannel.add(bct);
		
		Label label_18 = new Label("Reason Code");
		label_18.setBounds(190, 206, 80, 22);
		bucketadjpannel.add(label_18);
		
		JComboBox bct1 = new JComboBox(str1);
		bct1.setBounds(333, 210, 119, 20);
		bucketadjpannel.add(bct1);
		
		Label label_19 = new Label("Approved By Name");
		label_19.setBounds(190, 236, 120, 22);
		bucketadjpannel.add(label_19);

		JTextField textField_14 = new JTextField();
		textField_14.setBounds(333, 236, 119, 22);
		bucketadjpannel.add(textField_14);
		
		Label label_20 = new Label("Approved By PID");
		label_20.setBounds(190, 266, 120, 22);
		bucketadjpannel.add(label_20);

		JTextField textField_15 = new JTextField();
		textField_15.setBounds(333, 266, 119, 22);
		bucketadjpannel.add(textField_15);

		JButton btnNewButton_3 = new JButton("Process");
		btnNewButton_3.setBackground(new Color(0, 128, 0));
		btnNewButton_3.setBounds(317, 316, 99, 23);
		bucketadjpannel.add(btnNewButton_3);
		
		Label label_21 = new Label("* Enter the valid Store Number");
		label_21.setBounds(500, 66, 300, 22);
		label_21.setFont(new Font("Serif",Font.BOLD,20));
		label_21.setForeground(Color.BLACK);
		bucketadjpannel.add(label_21);
		
		Label label_22 = new Label("* Enter the Item Id");
		label_22.setBounds(500, 112, 300, 22);
		label_22.setFont(new Font("Serif",Font.BOLD,20));
		label_22.setForeground(Color.BLACK);
		bucketadjpannel.add(label_22);
		
		Label label_23 = new Label("* Enter the Imei Number");
		label_23.setBounds(500, 146, 300, 22);
		label_23.setFont(new Font("Serif",Font.BOLD,20));
		label_23.setForeground(Color.BLACK);
		bucketadjpannel.add(label_23);
		
		Label label_24 = new Label("* Select the valid bucket Id");
		label_24.setBounds(500, 176, 300, 22);
		label_24.setFont(new Font("Serif",Font.BOLD,20));
		label_24.setForeground(Color.BLACK);
		bucketadjpannel.add(label_24);
		
		Label label_25 = new Label("* Select the valid reason code");
		label_25.setBounds(500, 206, 300, 22);
		label_25.setFont(new Font("Serif",Font.BOLD,20));
		label_25.setForeground(Color.BLACK);
		bucketadjpannel.add(label_25);
		
		Label label_26 = new Label("* Enter the approval name");
		label_26.setBounds(500, 236, 300, 22);
		label_26.setFont(new Font("Serif",Font.BOLD,20));
		label_26.setForeground(Color.BLACK);
		bucketadjpannel.add(label_26);
		
		Label label_27 = new Label("* Enter the approval Pid");
		label_27.setBounds(500, 266, 300, 22);
		label_27.setFont(new Font("Serif",Font.BOLD,20));
		label_27.setForeground(Color.BLACK);
		bucketadjpannel.add(label_27);

		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String strnbr = textField_11.getText();
				String sku = textField_12.getText();
				String imei = textField_13.getText();
				String bucket = (String) bct.getSelectedItem();
				String reasonCode=(String) bct1.getSelectedItem();
				String approvedName=textField_14.getText();
				String approvedPid=textField_15.getText();

				if (!VerifyStoreNumber.validteStore(strnbr)) {
					SupportUI.statuslabel.setText("invalid store number");
					if (!VerifyBucketId.validteBucket(bucket)) {
					SupportUI.statuslabel.setText("invalid bucket id");
					if (!VerifyReasonCode.validteReasonCode(reasonCode)) {
						SupportUI.statuslabel.setText("invalid reason code");
				}}} else {
					textField_11.setText("");
					textField_12.setText("");
					textField_13.setText("");
					textField_14.setText("");
					textField_15.setText("");
					bct.setSelectedIndex(0);
					bct1.setSelectedIndex(0);
					bct.setToolTipText("");
					InvBucketAdjustServices ser=new InvBucketAdjustServices();
			       	Map<String,List<InvBucketAdjustBo>> txt=ser.getbucketTxtSheet(strnbr, sku, imei, bucket);
			      //conneting store db
			       	for (Map.Entry<String,List<InvBucketAdjustBo>> entry : txt.entrySet()) {
			       		String key=strnbr;
			       		List<InvBucketAdjustBo> listValues= entry.getValue();
			       		//SupportLogin login=new SupportLogin();
						//String pid=login.getPid_Nbr();
						String status=ser.connectingStore(key,listValues,approvedPid);
			       		System.out.println(status);
			       		
			       	}
			       	Connection con=null;
			       	try {
			       		Class.forName("oracle.jdbc.driver.OracleDriver");
			       		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xstore","dtv","dtv");
			       		if(con!=null) {
			       			Statement state=con.createStatement();
			       			state.executeQuery("Insert into DTV.INV_ADJUSTMENT_RECORD (RTL_LOC_ID,ITEM_ID,SERIAL_NBR,ORGANIZATION_ID,APPROVED_NAME,APPROVED_PID,REASON_CODE,BUCKET_ID,CREATE_DATE,CREATE_USER_ID) values ("+strnbr+",'"+sku+"','"+imei+"',1,'"+approvedName+"','"+approvedPid+"','"+reasonCode+"','"+bucket+"',SYSDATE,'"+approvedPid+"')");
			       			
			       		}
			       		
			       	}
			       	catch (Exception e) {
						e.printStackTrace();
						MyLogger.log(Level.INFO," Store"+ strnbr +":Not able to connect try after some time");
						SupportUI.statuslabel.setText("Not able to connect Database" +strnbr);
					}
			       	
			       	SupportUI.statuslabel.setText("Mnt file generated Succesfully");

				}

			}
		});

		return bucketadjpannel;

	}
}
