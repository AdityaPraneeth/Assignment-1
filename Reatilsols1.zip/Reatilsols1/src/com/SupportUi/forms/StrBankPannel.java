package com.SupportUi.forms;

import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.Retailsols.com.MyLogger;
import com.Retailsols.com.SupportUI;
import com.Retailsols.com.VerifyStoreNumber;
import com.retail.service.StrBankMnt;

public class StrBankPannel {

	private static String strnbr;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public static Panel getStrBankPanel()
	{
	
		Panel storebankpannel = new Panel();
		storebankpannel.setBackground(new Color(30, 144, 255));
		storebankpannel.setLayout(null);
		
		
		Label label_6 = new Label("Store Number");
		label_6.setBounds(205, 141, 82, 14);
		storebankpannel.add(label_6);
		
		JTextField textField_10 = new JTextField();
		textField_10.setBounds(320, 138, 86, 20);
		storebankpannel.add(textField_10);
		
		JButton btnNewButton_2 = new JButton("Process");
		btnNewButton_2.setBackground(new Color(255, 51, 0));
		btnNewButton_2.setBounds(244, 216, 162, 37);
		storebankpannel.add(btnNewButton_2);
		
		//instrution1
		JLabel instruction_1 = new JLabel("1.To Reset the Store Bank,Please Enter Store Number And Click on Process ");
		instruction_1.setFont(new Font("Serif",Font.PLAIN,16));
		instruction_1.setForeground(Color.BLACK);

		instruction_1.setBounds(459, 130, 750, 43);
		storebankpannel.add(instruction_1);
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				strnbr=textField_10.getText();
				if(!VerifyStoreNumber.validteStore(strnbr))
				{
					SupportUI.statuslabel.setText("Invalid store number");
					MyLogger.log(Level.INFO, "enterd invalid store number: "+strnbr+"");
				}
				else
				{
					StrBankMnt.genStrBankMnt(strnbr);
					SupportUI.statuslabel.setText("Mnt has been generated sucessfully");
					MyLogger.log(Level.INFO, "store bank reset mnt has genereted for the store: "+strnbr+"");
					textField_10.setText("");
				}
				
			}
		});
		
		return storebankpannel;
		
	}
}
