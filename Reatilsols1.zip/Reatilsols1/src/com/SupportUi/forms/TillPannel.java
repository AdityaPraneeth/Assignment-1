package com.SupportUi.forms;

import java.awt.Color;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.logging.Level;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.Retailsols.com.MyLogger;
import com.Retailsols.com.SupportUI;
import com.Retailsols.com.VerifyStoreNumber;
import com.SupportUi.validations.TillValidattions;
import com.retail.service.TillMnt;

public class TillPannel {

	public static String till_number;
	public static String reg_number;
	public static String store_number;
	// public static String status;

	/**
	 * @wbp.parser.entryPoint
	 */
	public static Panel getTillPannel()
	{
		Panel tillpanel = new Panel();
		tillpanel.setBackground(new Color(30, 144, 255));
		tillpanel.setLayout(null);
		//instrution1
		JLabel instruction_1 = new JLabel("1.For Issues Regarding Till,Enter Store number and Register number & click on process ");
		instruction_1.setFont(new Font("Serif", Font.PLAIN, 16));
		instruction_1.setForeground(Color.BLACK);
		instruction_1.setBounds(459, 130, 700, 43);
		tillpanel.add(instruction_1);
		//instruction2
		JLabel instruction_2 = new JLabel("2.Please Enter Valid Store number and Register number for Succesfull creation of mnt files");
		instruction_2.setFont(new Font("Serif", Font.PLAIN, 16));
		instruction_2.setForeground(Color.BLACK);
		instruction_2.setBounds(459, 172, 650, 43);
		tillpanel.add(instruction_2);
		//store number label
		JLabel lblStoreNumber = new JLabel("Store Number");
		lblStoreNumber.setForeground(Color.WHITE);
		lblStoreNumber.setBackground(Color.CYAN);
		lblStoreNumber.setBounds(205, 141, 82, 14);
		tillpanel.add(lblStoreNumber);
		//store number field
		JTextField Textfield_storenumber = new JTextField();
		 Textfield_storenumber.setBounds(320, 138, 86, 20);
		tillpanel.add(Textfield_storenumber);
		Textfield_storenumber.setColumns(10);
		Textfield_storenumber.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) { 
		    	  char caracter = e.getKeyChar();
		        if (Textfield_storenumber.getText().length() >= 4 ) {
		            e.consume();
		            }
                if (((caracter < '0') || (caracter > '9'))
                        && (caracter != '\b')) {
                    e.consume();
                }
		    }  
		});
		//Register label
		JLabel lblNewLabel = new JLabel("Register Number");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBackground(Color.MAGENTA);
		lblNewLabel.setBounds(205, 172, 100, 14);
		tillpanel.add(lblNewLabel);
		// Register field
		JTextField textField_register = new JTextField();
		textField_register.setBounds(320, 172, 86, 20);
		tillpanel.add(textField_register);
		textField_register.setColumns(10);
		textField_register.addKeyListener(new KeyAdapter() 
		 { 
			public void keyTyped(KeyEvent e) 
			{ 
				  char keyChar = e.getKeyChar(); 
			 if (((keyChar < '0') || (keyChar > '9')) && (keyChar != '\b')) { 
					  e.consume();
			 } 
			 if((textField_register.getText().length() >= 3) ||(!Character.isLetterOrDigit(keyChar)) ) { 
					  e.consume();
			 } } });
		
		// till button process
		JButton btnProcess = new JButton("Process");
		btnProcess.setBackground(new Color(255, 51, 0));
		btnProcess.setBounds(244, 216, 162, 37);
		tillpanel.add(btnProcess);
		btnProcess.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 store_number = Textfield_storenumber.getText();
			     reg_number =textField_register.getText();
			    
			     if(reg_number.length()>1) {
			    	   till_number=reg_number;
				 } 
				else {
					   till_number="0"+reg_number;
				 }
			     
			    if(!VerifyStoreNumber.validteStore(store_number))
			    {
			    	SupportUI.statuslabel.setText("Invalid store number");
			    	MyLogger.log(Level.INFO, "enterd invalid store number: "+store_number+"");
			    }
			    else if(!TillValidattions.validateRegNo(reg_number))
			    {
			    	SupportUI.statuslabel.setText("Invalid register number");
			    	MyLogger.log(Level.INFO, "enterd invalid register number: "+reg_number+"");
			    }
			    
			   	else
			    {
			    	TillMnt.genTillMnt(store_number, till_number, reg_number);
			    	SupportUI.statuslabel.setText("Mnt has been generated sucessfully");
			    	MyLogger.log(Level.INFO, "reset till mnt has genereted for the store: "+store_number+"\n"
			    			+ "Till no: "+till_number+"\n"+ "workstation: "+reg_number);
			    		
			    	textField_register.setText("");
			    	Textfield_storenumber.setText("");
			    		
			    	}
			    
			}			
		});
		return tillpanel;
	}
}
