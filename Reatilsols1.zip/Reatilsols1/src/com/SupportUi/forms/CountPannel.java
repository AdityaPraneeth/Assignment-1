package com.SupportUi.forms;

import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.Retailsols.com.MyLogger;
import com.Retailsols.com.SupportUI;
import com.Retailsols.com.VerifyStoreNumber;
import com.retail.service.CountMnt;
import com.retail.service.StrBankMnt;

public class CountPannel {
	
	private static String strnbr;
	private static String countid;

	/**
	 * @wbp.parser.entryPoint
	 */
	public static Panel getCountPanel()
	{
		Panel countpannel = new Panel();
		countpannel.setBackground(new Color(30, 144, 255));
		countpannel.setLayout(null);
		
		
		Label label_2 = new Label("Count Issue");
		countpannel.add(label_2);
		
		Label label_18 = new Label("Store Number");
		label_18.setBounds(205, 141, 82, 14);
		countpannel.add(label_18);
		
		JTextField textField_15 = new JTextField();
		textField_15.setBounds(320, 138, 86, 20);
		countpannel.add(textField_15);
		
		Label label_19 = new Label("Count ID");
		label_19.setBounds(205, 172, 100, 14);
		countpannel.add(label_19);
		
		JTextField textField_16 = new JTextField();
		textField_16.setBounds(320, 172, 86, 20);
		countpannel.add(textField_16);
		//instrution1
		JLabel instruction_1 = new JLabel("1.This functionality is being used in order to delete the counts ");
		instruction_1.setFont(new Font("Serif",Font.PLAIN,16));
		instruction_1.setForeground(Color.BLACK);

		instruction_1.setBounds(459, 130, 750, 43);
		countpannel.add(instruction_1);
		//instruction2
		JLabel instruction_2 = new
		JLabel("2.Please Enter Valid Charter Store number and Count id for Succesfull creation of mnt files" );
		instruction_2.setFont(new Font("Serif",Font.PLAIN,16));
		instruction_2.setForeground(Color.BLACK);

		instruction_2.setBounds(459, 172, 606, 43);
		countpannel.add(instruction_2);
				  
		 JLabel instruction_3 = new
		 JLabel("3.Count'id should start with YYYYMMDDStorenumber" );
		 instruction_3.setFont(new Font("Serif",Font.PLAIN,16));
	     instruction_3.setForeground(Color.BLACK);
		 instruction_3.setBounds(459, 210, 606, 36);
		 countpannel.add(instruction_3);

		 JLabel lblNewLabel = new JLabel("Approved By");
		 lblNewLabel.setForeground(Color.WHITE);
		 lblNewLabel.setBounds(210, 202, 100, 20);
		 countpannel.add(lblNewLabel);
			
		 String[] str = { "", "Andre" };
		 JComboBox comboBox = new JComboBox<Object>(str);
		 comboBox.setBounds(320, 202, 86, 20);
		 countpannel.add(comboBox);
		
		JButton btnNewButton_4 = new JButton("Process");
		btnNewButton_4.setBackground(new Color(255, 51, 0));
		btnNewButton_4.setBounds(244, 252, 162, 37);
		countpannel.add(btnNewButton_4);
		
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				strnbr=textField_15.getText();
				countid=textField_16.getText();
				if(!VerifyStoreNumber.validteStore(strnbr))
				{
					SupportUI.statuslabel.setText("Invalid store number");
					MyLogger.log(Level.INFO, "enterd invalid store number: "+strnbr+"");
				}
				else
				{
					CountMnt.genCountMnt(strnbr, countid);
					SupportUI.statuslabel.setText("Mnt has been generated sucessfully");
					MyLogger.log(Level.INFO, " delete count mnt has genereted for the store: "+strnbr+"");
					MyLogger.log(Level.INFO, "delete count mnt has genereted and Approved by: "+comboBox+"");
					
					textField_15.setText("");
					textField_16.setText("");
					comboBox.setSelectedIndex(0);
				}
				
			}
		});
		
		return countpannel;
	}
}
