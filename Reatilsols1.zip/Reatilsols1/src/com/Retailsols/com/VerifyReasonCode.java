package com.Retailsols.com;

import java.util.ArrayList;

public class VerifyReasonCode {
	public static boolean validteReasonCode(String reasonCode) 
	{
		ArrayList<String> ReasonCodeList= new ArrayList<String>();
		
		try {
			//storelist=getStoresList();
			ReasonCodeList.add("Damage");
			ReasonCodeList.add("Return To Stock");
			ReasonCodeList.add("Theft");
			ReasonCodeList.add("Demo");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  // fetching the stores list from xcenter
		if(ReasonCodeList.contains(reasonCode))
		return true;
		else
		return false;
		
	}

}
