package com.Retailsols.com;

import java.util.ArrayList;

public class VerifyBucketId {
	public static boolean validteBucket(String strnbr) 
	{
		ArrayList<String> bucketList= new ArrayList<String>();
		
		try {
			//storelist=getStoresList();
			bucketList.add("ON_HAND");
			bucketList.add("DAMAGED");
			bucketList.add("DEMO");
			bucketList.add("EARLY_UPGRADE");
			bucketList.add("TRADE_IN");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  // fetching the stores list from xcenter
		if(bucketList.contains(strnbr))
		return true;
		else
		return false;
		
	}

}
