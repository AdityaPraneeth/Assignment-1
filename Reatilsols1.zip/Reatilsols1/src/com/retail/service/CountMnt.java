package com.retail.service;

import java.io.File;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;



public class CountMnt {
	
	public static DateFormat df = new SimpleDateFormat("yyyy_MM_dd");
	public static Date dateobj = new Date();
	public static String date = new String(df.format(dateobj));

	public static void genCountMnt(String strnbr,String countid)
	{
		String dir="C:\\XstoreIssues\\MNT_FILES";
		try {
			PrintWriter pw = new PrintWriter(new File(
			dir + "\\"+"Delete_count_" + strnbr +".mnt"));
			StringBuilder br=new StringBuilder();
			br.append("<Header target_org_node='STORE:"+strnbr+"' download_name='Delete_Count_"+date+"' download_time='IMMEDIATE' apply_immediately='true' />\n");
			//<Header target_org_node="STORE:4026" download_name="Delete_Count_2020_07_23" download_time="IMMEDIATE" apply_immediately="true" />
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID ='"+countid+"'\n");
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT_P WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID ='"+countid+"'\n");
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT_BUCKET WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID='"+countid+"'\n");
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT_BUCKET_P WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID='"+countid+"'\n");
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT_SHEET WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID='"+countid+"'\n");
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT_SHEET_P WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID='"+countid+"'\n");
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT_SHEET_LINEITM WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID ='"+countid+ "'\n");
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT_SHEET_LINEITM_P WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID ='"+countid+ "'\n");
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT_SNAPSHOT WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID='"+countid+ "'\n");
			br.append("RUN_SQL|DELETE FROM DTV.INV_COUNT_SNAPSHOT_P WHERE RTL_LOC_ID='"+strnbr+"' AND INV_COUNT_ID='"+countid+ "'\n");
			br.append("RUN_SQL|COMMIT");
			pw.write(br.toString());
			pw.close();
		//	UploadFile.upload();
			
		}
			catch(Exception e) {
				
			}
	
	}
}
