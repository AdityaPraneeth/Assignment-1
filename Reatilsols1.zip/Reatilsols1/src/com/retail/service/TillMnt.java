package com.retail.service;

import java.io.File;
import java.io.PrintWriter;
import java.security.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class TillMnt {
		
	static DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	static Date dateobj = new Date();
	static String date = new String(df.format(dateobj));
	public static void genTillMnt(String strnbr,String tillno,String regno)
	{
		String dir="C:\\XstoreIssues\\MNT_FILES";
		try {
			PrintWriter pw = new PrintWriter(new File(
					dir + "\\" + strnbr + " _Till_Remove"+ ".mnt"));
			StringBuilder sb=new StringBuilder();
			sb.append("<Header download_id='Till."+strnbr+""+"."+date+"' target_org_node='STORE:"+strnbr+"' deployment_name='Till."+strnbr+"."+date+"' download_time='IMMEDIATE' apply_immediately='true'/> ");
			sb.append("\n");
			sb.append("RUN_SQL|UPDATE DTV.TSN_SESSION_WKSTN SET ATTACHED_FLAG = '0'"+" WHERE RTL_LOC_ID='"+strnbr+"'"+" AND WKSTN_ID='"+regno+"'"+" AND ATTACHED_FLAG='1'");
			sb.append("\n");
			sb.append("RUN_SQL|UPDATE DTV.TSN_TNDR_REPOSITORY_STATUS SET ISSUED_FLAG='0'"+", ACTIVE_SESSION_ID='' WHERE RTL_LOC_ID='"+strnbr+"'"+" AND TNDR_REPOSITORY_ID='TILL"+tillno+"'");
			sb.append("\n");
			sb.append("RUN_SQL|UPDATE DTV.TSN_SESSION SET STATCODE ='RECONCILED'"+", END_DATETIME= SYSDATE WHERE RTL_LOC_ID='"+strnbr+"'"+" AND TNDR_REPOSITORY_ID='TILL"+tillno+"'"+" AND STATCODE IN ('UNCOUNTED','ENDCOUNT','BEGINCOUNT')");
			sb.append("\n");
			sb.append("RUN_SQL|COMMIT");
			
			pw.write(sb.toString());
			pw.close();
			//UploadFile.upload();
			} catch (Exception e2) {
				
		  }
	}

	
}
