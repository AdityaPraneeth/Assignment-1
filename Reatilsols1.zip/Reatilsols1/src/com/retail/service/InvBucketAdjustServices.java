package com.retail.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.retail.bo.InvBucketAdjustBo;
import com.retail.dao.InvBucketAdjustmentDao;

public class InvBucketAdjustServices {

	InvBucketAdjustmentDao dao=new InvBucketAdjustmentDao();
	
	public List<InvBucketAdjustBo> getbucketSheet() {
		List<InvBucketAdjustBo> listinfo=null;
		
		try
	    {
			String filename = "./resources/Inv_Bucket_Adjust_Sheet.xlsx";
	        FileInputStream file = new FileInputStream(filename);
	 
	        //Create Workbook instance holding reference to .xlsx file
	        XSSFWorkbook workbook = new XSSFWorkbook(file);
	        
	        //Get first/desired sheet from the workbook
	        XSSFSheet sheet = workbook.getSheetAt(0);
	 
	        //Iterate through each rows one by one
	        Iterator<Row> rowIterator = sheet.iterator();
	        
	        listinfo=new ArrayList<InvBucketAdjustBo>();
	        while (rowIterator.hasNext()) 
	        {
	        	InvBucketAdjustBo sheetbo=null;
	            Row row = rowIterator.next();
	            if(row!=null) {
	            	sheetbo=new InvBucketAdjustBo();
	            	Cell cellStoreNbr=row.getCell(0);
	            	Cell cellSku=row.getCell(1);
	            	Cell cellImei=row.getCell(2);
	            	Cell cellBucket=row.getCell(3);
	            	if(!cellStoreNbr.toString().equals(null) || !cellStoreNbr.toString().equals(" ") || !cellStoreNbr.toString().equalsIgnoreCase("" )) {
	            		sheetbo.setStore_Nbr(cellStoreNbr.toString());
		            	sheetbo.setItem_Nbr(cellSku.toString());
		            	sheetbo.setSerial_Nbr(cellImei.toString());
		            	sheetbo.setBucket(cellBucket.toString());
		            	listinfo.add(sheetbo);
	            	}
	            	
	            }
	        }     
	        file.close();
	    } 
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
		
		
		return listinfo;
	}

	//connect xstore db
	public String connectingStore(String key,List<InvBucketAdjustBo> sheet,String pid) {
		String status="";
		status=dao.getAdjustbucket(key,sheet,pid);
		return status;
	}


	//reading txt file
	public Map<String,List<InvBucketAdjustBo>> getbucketTxtSheet(String storeNumber, String SkuNumber, String ImeiNumber, String bucketId) {
		List<InvBucketAdjustBo> listInfo=null;
		Map<String,List<InvBucketAdjustBo>> mapInfo=new HashMap<String, List<InvBucketAdjustBo>>();
		try {
		      PrintWriter pw = new PrintWriter(new File("C:\\XstoreIssues\\resources\\Inv_Bucket_Adjustment_sheet.txt"));
		      StringBuilder ds = new StringBuilder();
		      pw.write(storeNumber);
		      pw.write(" ");
		      pw.write(SkuNumber);
		      pw.write(" ");
		      pw.write(ImeiNumber);
		      pw.write(" ");
		      pw.write(bucketId);
		      pw.write(" ");
		      pw.write("LINE_END");
		      pw.write(System.getProperty("line.separator"));
		      pw.write("STORE_END");
		      pw.close();

	    }
	    catch (FileNotFoundException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	    }
	    // System.out.println("Completed generating reset bucket adjustment mnt file");
	    // JOptionPane.showMessageDialog(null,"Successfully generted resetBucketAjd mnt file");

			String filename = "C:/XstoreIssues/resources/Inv_Bucket_Adjustment_sheet.txt";
			Scanner scan;
			try {
				scan = new Scanner(new File(filename));
				String stores = new String();
				while (scan.hasNextLine()) {
					stores=stores+" "+scan.next();
				}
				scan.close();
				
				//@jagadish Process for reading data from the file and storing into MAP.
				InvBucketAdjustBo bo=null;
				//Separating Store level 
				
				String storeLevel[]=stores.split("STORE_END");
				String key=null;
				for (String lineLevel : storeLevel) {
					//Separating line level in store 
					String singleInfo[]=lineLevel.split("LINE_END");
					boolean flag=true;
					listInfo =new ArrayList<InvBucketAdjustBo>();
					for (String info : singleInfo) {
						String sp[]=info.split(" ");
						if(flag==true) {
							key=sp[1];
							flag=false;
						}
						if(sp.length>1) {
							bo=new InvBucketAdjustBo();
							bo.setStore_Nbr(sp[1]);
							bo.setItem_Nbr(sp[2]);
							bo.setSerial_Nbr(sp[3]);
							bo.setBucket(sp[4]);
							listInfo.add(bo);
						}	
					}
				
				//process for to handle the multiple IMEI
				
				//creating map object for making mearge multiple imei to single sku
				Map<String, InvBucketAdjustBo> mapbo=null; 
				mapbo=new HashMap<String, InvBucketAdjustBo>();
				for (InvBucketAdjustBo inv : listInfo) {
					if(inv!=null) {
						//get sku from the map object
						InvBucketAdjustBo info=mapbo.get(inv.getItem_Nbr());
						if(info==null) {
							//SKU not their in map object the put it , key as sku and values is object
							mapbo.put(inv.getItem_Nbr(), inv);
						}else if(info!=null) {
							//SKU is available in map object, then get sku object from map object, then concate the imei part  
							String fnlImei=info.getSerial_Nbr()+","+inv.getSerial_Nbr();
							info.setSerial_Nbr(fnlImei);
							mapbo.put(inv.getItem_Nbr(), info);
						}
					}
				}
				
				//process for converting map object to list object
				List<InvBucketAdjustBo> finalListbo=null;
				finalListbo=new ArrayList<InvBucketAdjustBo>();
				for (Map.Entry<String , InvBucketAdjustBo> mapToList: mapbo.entrySet()) {
					finalListbo.add(mapToList.getValue());
				}
				mapInfo.put(key, finalListbo);
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return mapInfo;
	}

}
