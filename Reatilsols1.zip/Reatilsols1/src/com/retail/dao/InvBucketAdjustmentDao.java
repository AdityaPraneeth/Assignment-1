package com.retail.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

import com.Retailsols.com.MyLogger;
import com.Retailsols.com.SupportUI;
import com.retail.bo.InvBucketAdjustBo;
import com.retail.bo.InvBucketAdjustDBBo;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.pool.OracleDataSource;

public class InvBucketAdjustmentDao {

	//store DB info
	//Store db connection
		public static OracleConnection getStoreDBConnection(String pStoreNbr) throws SQLException {
			OracleConnection ocon = null;

			OracleDataSource ods = new OracleDataSource();
			ods.setServerName("localhost");
			ods.setUser("dtv"); 
			ods.setPassword("dtv");
			ods.setServiceName("xstore");
			ods.setPortNumber(1521);
			ods.setDriverType("thin");

			ocon = (OracleConnection) ods.getConnection();

			ocon.setAutoCommit(false);
			return ocon;
		}
		
	//connecting xstore DB
	public String getAdjustbucket(String key,List<InvBucketAdjustBo> sheet,String pid) {
		String status=null;
			OracleConnection ocon = null;
			Statement stmt= null;
			Statement stmt1= null;
			Statement stmt2= null;
			try {
				ocon = getStoreDBConnection(key);
				 stmt = ocon.createStatement();
				 stmt1 = ocon.createStatement();
				 stmt2 = ocon.createStatement();
			} catch (Exception e) {
				e.getMessage();
			}
			try {
				 stmt = ocon.createStatement();
				//int count=0;
				 List<StringBuilder> quries=new ArrayList<StringBuilder>(); 
				for (InvBucketAdjustBo inv : sheet) {
					if(!inv.getStore_Nbr().isEmpty()) {
					
					String Imei[]=inv.getSerial_Nbr().split(",");
					StringBuilder imeiList=new StringBuilder();
					imeiList.append("(");
					for (String strimei : Imei) {
						imeiList.append("'"+strimei+"',");
					}
					imeiList.append("''");
					imeiList.append(")");
					
					String stock_Ledger_Acc="SELECT RTL_LOC_ID, BUCKET_ID, ITEM_ID, UNITCOUNT FROM DTV.INV_STOCK_LEDGER_ACCT WHERE ITEM_ID ='"+inv.getItem_Nbr()+"' AND BUCKET_ID='"+inv.getBucket()+"'";
					String serialize_Stock_ledger_acc="SELECT RTL_LOC_ID, BUCKET_ID, ITEM_ID, SERIAL_NBR FROM DTV.INV_SERIALIZED_STOCK_LEDGER WHERE SERIAL_NBR IN "+imeiList+"";
					
					String serialize_Stock_ledger_acc_with_sku="SELECT RTL_LOC_ID, BUCKET_ID, ITEM_ID, SERIAL_NBR FROM DTV.INV_SERIALIZED_STOCK_LEDGER WHERE ITEM_ID ='"+inv.getItem_Nbr()+"'";
					
					ResultSet rest_Stock_Ledger_Acc = stmt.executeQuery(stock_Ledger_Acc);
					
					ResultSet rest_serialize_Stock_ledger_acc = stmt1.executeQuery(serialize_Stock_ledger_acc);
					
					ResultSet rset_serialize_Stock_ledger_acc_with_sku = stmt2.executeQuery(serialize_Stock_ledger_acc_with_sku);
					
					//getting stock ledger account info from result set and creating java object
					InvBucketAdjustDBBo dbStockLdgerInfo=null;
					if (rest_Stock_Ledger_Acc.next()) {
						dbStockLdgerInfo=new InvBucketAdjustDBBo();
						dbStockLdgerInfo.setStore_Nbr(rest_Stock_Ledger_Acc.getString(1));
						dbStockLdgerInfo.setBucket(rest_Stock_Ledger_Acc.getString(2));
						dbStockLdgerInfo.setItem_Nbr(rest_Stock_Ledger_Acc.getString(3));
						dbStockLdgerInfo.setQty(rest_Stock_Ledger_Acc.getInt(4));
					}
					
					
					//getting Serialized stock ledger account info from result set creating object
					List<InvBucketAdjustDBBo> dbSerilizedStockLedger=null;
					dbSerilizedStockLedger=new ArrayList<InvBucketAdjustDBBo>();
					InvBucketAdjustDBBo dbSerInfo=null;
					while (rest_serialize_Stock_ledger_acc.next()) {
						dbSerInfo=new InvBucketAdjustDBBo();
						dbSerInfo.setStore_Nbr(rest_serialize_Stock_ledger_acc.getString(1));
						dbSerInfo.setBucket(rest_serialize_Stock_ledger_acc.getString(2));
						dbSerInfo.setItem_Nbr(rest_serialize_Stock_ledger_acc.getString(3));
						dbSerInfo.setSerial_Nbr(rest_serialize_Stock_ledger_acc.getString(4));
						dbSerilizedStockLedger.add(dbSerInfo);
					} 
			
					//getting Serialized stock ledger account info with Sku , 
					List<InvBucketAdjustDBBo> dbSerilizedStockLedgerwithSku=null;
					dbSerilizedStockLedgerwithSku=new ArrayList<InvBucketAdjustDBBo>();
					InvBucketAdjustDBBo dbSerSKUInfo=null;
					while (rset_serialize_Stock_ledger_acc_with_sku.next()) {
						dbSerSKUInfo=new InvBucketAdjustDBBo();
						dbSerSKUInfo.setStore_Nbr(rset_serialize_Stock_ledger_acc_with_sku.getString(1));
						dbSerSKUInfo.setBucket(rset_serialize_Stock_ledger_acc_with_sku.getString(2));
						dbSerSKUInfo.setItem_Nbr(rset_serialize_Stock_ledger_acc_with_sku.getString(3));
						dbSerSKUInfo.setSerial_Nbr(rset_serialize_Stock_ledger_acc_with_sku.getString(4));
						dbSerilizedStockLedgerwithSku.add(dbSerSKUInfo);
					} 
					
					//Calling menthod to create query for a connected store
					StringBuilder mntQuerys=getGeneratingSqlQuery(dbStockLdgerInfo,dbSerilizedStockLedger,inv,dbSerilizedStockLedgerwithSku,pid);
					quries.add(mntQuerys);
					/*Commenting for some reason
					 * String Query="select DISTINCT issl.RTL_LOC_ID, issl.BUCKET_ID, issl.ITEM_ID, issl.SERIAL_NBR, sla.UNITCOUNT"+ 
					  		" FROM  DTV.inv_serialized_stock_ledger issl RIGHT JOIN DTV.inv_stock_ledger_acct sla"+ 
					  		" ON issl.RTL_LOC_ID=sla.RTL_LOC_ID AND issl.BUCKET_ID=sla.BUCKET_ID AND issl.ITEM_ID=sla.ITEM_ID"+ 
					  		" WHERE issl.RTL_LOC_ID ='"+inv.getStore_Nbr()+"'"+ 
					  		" AND issl.ITEM_ID ='"+inv.getItem_Nbr()+"'"+ 
					  		" AND  issl.SERIAL_NBR IN "+imeiList+""+ 
					  		" ORDER BY issl.RTL_LOC_ID";
					ResultSet rest = stmt.executeQuery(Query);
					*/	
						//commenting for some reason
						/*List<InvBucketAdjustDBBo> dbinfo=new ArrayList<InvBucketAdjustDBBo>();
						InvBucketAdjustDBBo db=null;
						while (rset.next()) {
							db=new InvBucketAdjustDBBo();
							db.setStore_Nbr(rset.getString(1));
							db.setBucket(rset.getString(2));
							db.setItem_Nbr(rset.getString(3));
							db.setSerial_Nbr(rset.getString(4));
							db.setQty(rset.getInt(5));
							dbinfo.add(db);
						}*/ 
						
					//calling to creating mnt for store
					/*status=getCreateMnt(dbinfo,inv,count);
					String report="Inv Bucket adjustment mnt has been created for the  store "+inv.getStore_Nbr()+ " in Gen-mnt folder";
					count++;
					System.out.println(report);*/
					
				}// close if condition, if no item id present, 
					
			  }	// close for each codition
				
			//Calling the method to create mnt file for a store
			status=getGeneratingMntfile(quries,key);
				
			} catch (Exception e) {
				e.printStackTrace();
				MyLogger.log(Level.INFO," Store"+ key +":Not able to connect try after some time");
				SupportUI.statuslabel.setText("Not able to connect Database" +key);
			}
		return status;
	}
	/*public void getDataRecord(String key,String approvedName,String approvedPid,String reasonCode,String SkuNumber,String ImeiNumber,String bucketId ) {
			OracleConnection ocon = null;
			Statement stmt= null;
			try {
				ocon = getStoreDBConnection(key);
				 stmt = ocon.createStatement();
				 //String insertInvRecord="Insert into DTV.INV_ADJUSTMENT_RECORD (RTL_LOC_ID,ITEM_ID,SERIAL_NBR,ORGANIZATION_ID,APPROVED_NAME,APPROVED_PID,REASON_CODE,BUCKET_ID,CREATE_DATE,CREATE_USER_ID) values ("+key+",'"+SkuNumber+"','"+ImeiNumber+"',1,'"+approvedName+"','"+approvedPid+"','"+reasonCode+"','"+bucketId+"',SYSDATE,'"+approvedPid+"')";
						 stmt.executeUpdate("Insert into DTV.INV_ADJUSTMENT_RECORD (RTL_LOC_ID,ITEM_ID,SERIAL_NBR,ORGANIZATION_ID,APPROVED_NAME,APPROVED_PID,REASON_CODE,BUCKET_ID,CREATE_DATE,CREATE_USER_ID) values ("+key+",'"+SkuNumber+"','"+ImeiNumber+"',1,'"+approvedName+"','"+approvedPid+"','"+reasonCode+"','"+bucketId+"',SYSDATE,'"+approvedPid+"')");

			}
			catch (Exception e) {
				e.printStackTrace();
				MyLogger.log(Level.INFO," Store"+ key +":Not able to connect try after some time");
				SupportUI.statuslabel.setText("Not able to connect Database" +key);
			}
	}*/
	
	// Generating mnt file by using query.
	public String getGeneratingMntfile(List<StringBuilder> mntQuerys,String key) {
		SimpleDateFormat sf= new SimpleDateFormat("yyyyMMdd-hhmmss");
		String filename="C:/XstoreIssues/MNT_FILES/"+key+"_InvAdjustBucket_"+sf.format(new Date())+".mnt";
		File filepath= new File(filename);
		try {
		if (!filepath.exists()) {
				filepath.createNewFile();
			}
		} catch (IOException e) {
			e.toString();
		}
		PrintWriter writer=null;
		try {
			writer = new PrintWriter(filepath);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			// Header part for mnt
			StringBuilder headder=new StringBuilder();
			String strDate= sf.format(new Date());
			headder.append("<Header download_id='Inv_Adjustment."+key+"."+strDate+"' target_org_node='STORE:"+key+"' deployment_name='Inv_Adjustment."+key+"."+strDate+"' download_time='IMMEDIATE' apply_immediately='true' />");
			StringBuilder end=new StringBuilder();
			end.append("RUN_SQL|COMMIT");
			writer.println(headder.toString());
			for (StringBuilder sb : mntQuerys) {
				writer.println(sb.toString());
			}
			writer.println(end.toString());
			
			} catch (Exception e) {
				
		  }
		finally {
			writer.close();
		}
		MyLogger.log(Level.INFO, "mnt has been created for the store "+key);
		return "mnt has been created for the store "+key;
		
	}

	//Generating query for sku and imei by using stock ledger account and serialized stock ledger table 
	public StringBuilder getGeneratingSqlQuery(InvBucketAdjustDBBo dbStockLdgerInfo, List<InvBucketAdjustDBBo> dbSerilizedStockLedger,InvBucketAdjustBo sheet,List<InvBucketAdjustDBBo> dbSerilizedStockLedgerwithSku,String pid) {
		StringBuilder stockQuery=null;
		stockQuery=new StringBuilder();
		String Imei[]=sheet.getSerial_Nbr().split(",");
		int sheetQty=Imei.length;
		
		//Process for creating query for Stock ledger table 
		if(dbStockLdgerInfo!=null) {
			if(sheet.getStore_Nbr().equalsIgnoreCase(dbStockLdgerInfo.getStore_Nbr())) {
				if(sheet.getItem_Nbr().equalsIgnoreCase(dbStockLdgerInfo.getItem_Nbr())) {
					if(sheet.getBucket().equalsIgnoreCase(dbStockLdgerInfo.getBucket())) { 
						//item is present in db with correct bucket and store, then updating existing record in Store Ledger Account.
						
						//int finalQty=sheetQty+dbStockLdgerInfo.getQty();

						// shakir recommanded
						int finalQty=getFinalQty(dbStockLdgerInfo,dbSerilizedStockLedgerwithSku)+sheetQty;
						
						stockQuery.append("RUN_SQL|UPDATE DTV.INV_STOCK_LEDGER_ACCT SET UNITCOUNT='"+finalQty+"', BUCKET_ID='"+sheet.getBucket()+"', UPDATE_DATE=SYSDATE, UPDATE_USER_ID='"+pid+"' WHERE ITEM_ID='"+dbStockLdgerInfo.getItem_Nbr()+"' AND BUCKET_ID='"+dbStockLdgerInfo.getBucket()+"' AND RTL_LOC_ID='"+dbStockLdgerInfo.getStore_Nbr()+"' AND ORGANIZATION_ID='1'");
						stockQuery.append("\n");
					}else {
						//item is present in db with different bucket, then inserting new record in Store Ledger Account.
						stockQuery.append("RUN_SQL|INSERT INTO DTV.INV_STOCK_LEDGER_ACCT VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+sheetQty+"','',SYSDATE,'"+pid+"',SYSDATE,'"+pid+"','')");
						stockQuery.append("\n");
					}
				} //item is present in db with correct store number if condition satisfied
			}else {
				//Item id present in DB but different store. then inserting new record in Store Ledger Account.
				stockQuery.append("RUN_SQL|INSERT INTO DTV.INV_STOCK_LEDGER_ACCT VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+sheetQty+"','',SYSDATE,'"+pid+"',SYSDATE,'"+pid+"','')");
				stockQuery.append("\n");
			}
		}else{
			//Item id not present in DB. then inserting new record in Store Ledger Account.
		    stockQuery.append("RUN_SQL|INSERT INTO DTV.INV_STOCK_LEDGER_ACCT VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+sheetQty+"','',SYSDATE,'"+pid+"',SYSDATE,'"+pid+"','')");
			stockQuery.append("\n");
		}
		
		
		//Process for creating query for Serialize Stock ledger table
		
		// SERILIZED stock ledger ITEM having one IMEI 
		if(Imei.length==1) {
			String sheetimei=Imei[0];
			if(!dbSerilizedStockLedger.isEmpty()) {
				InvBucketAdjustDBBo dbSingleSer=dbSerilizedStockLedger.get(0);
			if(sheet.getStore_Nbr().equalsIgnoreCase(dbSingleSer.getStore_Nbr())) {
				if(sheetimei.equalsIgnoreCase(dbSingleSer.getSerial_Nbr())) {
					//Imei is present in DB then updating existing record in Serialized Store Ledger Account.Because imei is unique
					stockQuery.append("RUN_SQL|UPDATE DTV.INV_SERIALIZED_STOCK_LEDGER SET ITEM_ID='"+sheet.getItem_Nbr()+"', BUCKET_ID='"+sheet.getBucket()+"', UPDATE_DATE=SYSDATE, UPDATE_USER_ID='"+pid+"' WHERE SERIAL_NBR='"+sheetimei+"' AND BUCKET_ID='"+dbSingleSer.getBucket()+"' AND RTL_LOC_ID='"+dbSingleSer.getStore_Nbr()+"' AND ORGANIZATION_ID='1'");
					stockQuery.append("\n");
				}else {
					//Imei id not present in DB. then inserting new record in Serialized Store Ledger Account.
					stockQuery.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+sheetimei+"',SYSDATE,'"+pid+"',SYSDATE,'"+pid+"','')");
					stockQuery.append("\n");
				}
			}else {
				//Imei is present in DB with different store number, then insert record into Serialized Store Ledger Account.Because imei is unique
			    stockQuery.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+sheetimei+"',SYSDATE,'"+pid+"',SYSDATE,'"+pid+"','')");
				stockQuery.append("\n");
			}
		  }else {
			//Imei is present in DB with different store number, then insert record into Serialized Store Ledger Account.Because imei is unique
				stockQuery.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+sheetimei+"',SYSDATE,'"+pid+"',SYSDATE,'"+pid+"','')");
				stockQuery.append("\n");
		  }
		}
		
		//SERILIZED stock ledger ITEM having multiple IMEI
		if(Imei.length>1) {
			//finding the imei in Sheet list

			for (String shetImei : Imei) {   //Sheet Imei list iteration
				String fnlimei=null;
				InvBucketAdjustDBBo singleimei=null;
				for (InvBucketAdjustDBBo InvBucketAdjustDBBo : dbSerilizedStockLedger) {
					if(shetImei.equalsIgnoreCase(InvBucketAdjustDBBo.getSerial_Nbr())) {
						fnlimei=InvBucketAdjustDBBo.getSerial_Nbr();
						singleimei=InvBucketAdjustDBBo;
					}
				}
			
				//working with single imei
				if(fnlimei!=null) {
					if(sheet.getStore_Nbr().equalsIgnoreCase(singleimei.getStore_Nbr())) {
						if(shetImei.equalsIgnoreCase(singleimei.getSerial_Nbr())) {
							//Imei is present in DB then updating existing record in Serialized Store Ledger Account.Because imei is unique
							stockQuery.append("RUN_SQL|UPDATE DTV.INV_SERIALIZED_STOCK_LEDGER SET ITEM_ID='"+sheet.getItem_Nbr()+"', BUCKET_ID='"+sheet.getBucket()+"', UPDATE_DATE=SYSDATE, UPDATE_USER_ID='"+pid+"' WHERE SERIAL_NBR='"+shetImei+"' AND BUCKET_ID='"+singleimei.getBucket()+"' AND RTL_LOC_ID='"+singleimei.getStore_Nbr()+"' AND ORGANIZATION_ID='1'");
							stockQuery.append("\n");
						}else {
							//Imei id not present in DB. then inserting new record in Serialized Store Ledger Account.
							stockQuery.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+shetImei+"',SYSDATE,'"+pid+"',SYSDATE,'"+pid+"','')");
							stockQuery.append("\n");
						}
					}else {
						//Imei id present in DB. then inserting new record in Serialized Store Ledger Account.
						stockQuery.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+shetImei+"',SYSDATE,'"+pid+"',SYSDATE,'"+pid+"','')");
						stockQuery.append("\n");
					}
				}else {
					//Imei id not present in DB. then inserting new record in Serialized Store Ledger Account.
					stockQuery.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+shetImei+"',SYSDATE,'"+pid+"',SYSDATE,'"+pid+"','')");
					stockQuery.append("\n");
				}
			}
		}//closing multiple imei process
		
		// ENd SERILIZED stock ledger sku having one IMEI
		
	return stockQuery;
	}

	// get final qty
	public int getFinalQty(InvBucketAdjustDBBo dbStockLdgerInfo, List<InvBucketAdjustDBBo> dbSerilizedStockLedger) {
		int fnalQty=0;
		dbStockLdgerInfo.getQty();
		
		for (InvBucketAdjustDBBo invBucketAdjustDBBo : dbSerilizedStockLedger) {
			if(dbStockLdgerInfo.getItem_Nbr().equalsIgnoreCase(invBucketAdjustDBBo.getItem_Nbr())){
				if(dbStockLdgerInfo.getBucket().equalsIgnoreCase(invBucketAdjustDBBo.getBucket())) {
					fnalQty++;
				}
			}
		}
		return fnalQty;
	}

/*	//carating mnt file for store
	  private String getCreateMnt(List<InvBucketAdjustDBBo> dblist, InvBucketAdjustBo sheet, int count) {
		 
		  //SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd-yyyy");
			//String date = simpleDateFormat.format(new Date());
			//String sno=sheet.getStore_Nbr().substring(0, 4);
			String filename="./gen-mnt/"+sheet.getStore_Nbr()+"_"+count+""+"_InvAdjustBucket.mnt";
			File filepath= new File(filename);
			try {
			if (!filepath.exists()) {
					filepath.createNewFile();
				}
			} catch (IOException e) {
				e.toString();
			}
			PrintWriter writer=null;
			try {
				writer = new PrintWriter(filepath);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try {
				StringBuilder sb = new StringBuilder();
				String Imei[]=sheet.getSerial_Nbr().split(",,");
				int sheetQty=Imei.length;
				// Header part for mnt
				sb.append("<Header download_id='"+sheet.getBucket()+"."+sheet.getStore_Nbr()+".2019-12-10' target_org_node='STORE:"+sheet.getStore_Nbr()+"' deployment_name='"+sheet.getBucket()+"."+sheet.getStore_Nbr()+"2019-12-10' download_time='IMMEDIATE' apply_immediately='true' />");
				sb.append("\n");
				if(!dblist.isEmpty()) {
					boolean flag=true;
					for (InvBucketAdjustDBBo dbinfo : dblist) {
						if(dbinfo!=null) {
							//stock ledger
							if(flag==true) {
							if(sheet.getItem_Nbr().equalsIgnoreCase(dbinfo.getItem_Nbr())) {
								if(sheet.getBucket().equalsIgnoreCase(dbinfo.getBucket())) {
									//item is ther updating accroding sheet
								//String sheetQty[]=sheet.getSerial_Nbr().split(",");	
								int finalQty=sheetQty+dbinfo.getQty();
								sb.append("RUN_SQL|UPDATE DTV.INV_STOCK_LEDGER_ACCT SET UNITCOUNT='"+finalQty+"',BUCKET_ID='"+sheet.getBucket()+"' WHERE ITEM_ID='"+sheet.getItem_Nbr()+"' AND RTL_LOC_ID='"+sheet.getStore_Nbr()+"'");
								sb.append("\n");
								}
							}else {
								if(flag==true) {
									//item not there in the db: means imei linked with other sku
									sb.append("RUN_SQL|INSERT INTO DTV.INV_STOCK_LEDGER_ACCT VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+sheetQty+dbinfo.getQty()+"','','10-OCT-19 06.46.30.464000000 PM','6085228','','','')");
									sb.append("\n");
								}	
							}
						}//boolean value need to update to end the stock ledger acc
							flag=false;


							// Start SERILIZED stock ledger sku having one IMEI
							if(Imei.length==1) {
								for (String stoImei : Imei) {
									if(stoImei.equalsIgnoreCase(dbinfo.getSerial_Nbr())) {
										//IMIE is ther updating accroding sheet
										sb.append("RUN_SQL|UPDATE DTV.INV_SERIALIZED_STOCK_LEDGER SET ITEM_ID='"+sheet.getItem_Nbr()+"' AND BUCKET_ID='"+sheet.getBucket()+"' WHERE SERIAL_NBR='"+stoImei+"' AND RTL_LOC_ID='"+sheet.getStore_Nbr()+"'");
										sb.append("\n");
									} else {
										//IMEI not avili in db
										sb.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+stoImei+"','01-OCT-19 06.54.21.252000000 PM','DATALOADER','01-OCT-19 06.54.21.252000000 PM','DATALOADER','')");
										sb.append("\n");
									}
								}
							}
							// SERILIZED stock ledger sku having muiltiple IMEI 
							if(Imei.length>1) {
								String fnlimei=null;	//finding the imei in Sheet list
								for (String shetImei : Imei) {
									if(dbinfo.getSerial_Nbr().equalsIgnoreCase(shetImei)) {
										fnlimei=dbinfo.getSerial_Nbr();
									}
								}
								
								//working with single imei
								if(fnlimei!=null) {
									//IMIE is ther updating accroding sheet
										sb.append("RUN_SQL|UPDATE DTV.INV_SERIALIZED_STOCK_LEDGER SET ITEM_ID='"+sheet.getItem_Nbr()+"' AND BUCKET_ID='"+sheet.getBucket()+"' WHERE SERIAL_NBR='"+fnlimei+"' AND RTL_LOC_ID='"+sheet.getStore_Nbr()+"'");
										sb.append("\n");
									} else {
										//IMEI not avili in db
										sb.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+fnlimei+"','01-OCT-19 06.54.21.252000000 PM','DATALOADER','01-OCT-19 06.54.21.252000000 PM','DATALOADER','')");
										sb.append("\n");
									}
								
							}
							// ENd SERILIZED stock ledger sku having one IMEI
						}else {
							//no info in DB null , so now you need insert Stock ledger and seri stock ledger
							sb.append("RUN_SQL|INSERT INTO DTV.INV_STOCK_LEDGER_ACCT VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+sheetQty+dbinfo.getQty()+"','','10-OCT-19 06.46.30.464000000 PM','6085228','','','')");
							sb.append("\n");
							for (String strimei : Imei) {
							sb.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+strimei+"','01-OCT-19 06.54.21.252000000 PM','DATALOADER','01-OCT-19 06.54.21.252000000 PM','DATALOADER','')");
							sb.append("\n");
						}
					}
				}
					
			}else {
				//no info in DB null , so now you need insert Stock ledger and seri stock ledger
				sb.append("RUN_SQL|INSERT INTO DTV.INV_STOCK_LEDGER_ACCT VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+sheetQty+"','','10-OCT-19 06.46.30.464000000 PM','6085228','','','')");
				sb.append("\n");
				for (String strimei : Imei) {
				sb.append("RUN_SQL|INSERT INTO DTV.INV_SERIALIZED_STOCK_LEDGER VALUES ('1','"+sheet.getStore_Nbr()+"','DEFAULT','"+sheet.getBucket()+"','"+sheet.getItem_Nbr()+"','"+strimei+"','01-OCT-19 06.54.21.252000000 PM','DATALOADER','01-OCT-19 06.54.21.252000000 PM','DATALOADER','')");
				sb.append("\n");
			}
			}	
				sb.append("RUN_SQL|COMMIT");
				writer.println(sb.toString());
				} catch (Exception e) {
					
			  }
			finally {
				writer.close();
			}  
		return "Check out all mnt in Gen-mnt folder.........";
	}
*/
	
}
