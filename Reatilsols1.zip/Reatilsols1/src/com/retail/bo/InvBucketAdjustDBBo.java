package com.retail.bo;

import java.util.List;

public class InvBucketAdjustDBBo {

	private String Store_Nbr;
	private String item_Nbr;
	private String bucket;
	private String Serial_Nbr;
	private int qty;
	public String getStore_Nbr() {
		return Store_Nbr;
	}
	public void setStore_Nbr(String store_Nbr) {
		Store_Nbr = store_Nbr;
	}
	public String getItem_Nbr() {
		return item_Nbr;
	}
	public void setItem_Nbr(String item_Nbr) {
		this.item_Nbr = item_Nbr;
	}
	public String getBucket() {
		return bucket;
	}
	public void setBucket(String bucket) {
		this.bucket = bucket;
	}
	
	
	public String getSerial_Nbr() {
		return Serial_Nbr;
	}
	public void setSerial_Nbr(String serial_Nbr) {
		Serial_Nbr = serial_Nbr;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "InvBucketAdjustDBBo [Store_Nbr=" + Store_Nbr + ", item_Nbr=" + item_Nbr + ", bucket=" + bucket
				+ ", Serial_Nbr=" + Serial_Nbr + ", qty=" + qty + "]";
	}
	
	
}
